/**
 * 
 */
package Game_System;

import java.util.*;

/**
 * Description
 *
 * @author	James C. Cot�
 * @version v1.0 - Mar 25, 2014
 */
public class Player 
{
	private ArrayList<Item> m_Inventory;
	
	public Player()
	{
		m_Inventory = new ArrayList<Item>();
	}
	
	

}
