/**
 * 
 */
package Scene_Manager;

/**
 * Description
 *
 * @author	James C. Cot�
 * @version v1.0 - Mar 25, 2014
 */
public class Scene {

}
