package Assignment3;

import Game_System.*;

public class main {

	public static void main(String[] args) 
	{
		GameSystem gameSystem = new GameSystem();
		gameSystem.run();
	}

}
